# -*- coding: utf-8 -*-
import scrapy
import re
from items import HsspiderItem
from scrapy.http import Request, FormRequest
from scrapy.xlib.pydispatch import dispatcher
import logging 
from scrapy.utils.log import configure_logging  
from scrapy import signals
import random
import string

class HSSpider(scrapy.Spider):
	name = "home_supplies_spider"
	allowed_domains = ["esources.co.uk"]
	start_urls = (
		"https://www.esources.co.uk/wholesale-suppliers/14/",
	)
	base_url = "https://www.esources.co.uk"
	site = "esources"
	hash = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(20))

	
	def __init__(self):
		dispatcher.connect(self.finished, signals.engine_stopped)

	configure_logging(install_root_handler=False)
	logging.basicConfig(filename='log.txt', format='%(levelname)s: %(message)s', level=logging.ERROR)

	def finished(self):
		print '---------- FINISHED ----------'
		print 'Hash: ' + self.hash
		print 'Site: ' + self.site
		print 'Name: ' + self.name
		print '------------------------------'

	def parse(self, response):
		item = HsspiderItem()
		prods = response.xpath("//div[@id='spread-maincol']/div[contains(@class, 'row')]")
		for prod in prods:
			item['name'] = prod.xpath("*//h2/a/text()").extract()[0]
			try:
				item['website'] = prod.xpath("*//a[contains(text(),'Website')]/@href").extract()[0]
			except:
				item['website'] = ''
			yield item
		try:
			next_page = response.xpath("//a[contains(text(), 'Next')]/@href").extract()[0]
			yield Request(next_page, callback = self.parse, dont_filter = True)
		except:
			print("Last Page !!!")

		

