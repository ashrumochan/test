package org.tetra.validate

import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}

class Validator {
  
  def nullCheck(sourceDataFrame: DataFrame): String = {
    
    boolean testState = false
    val cols = sourceDataFrame.columns.toSeq
    for(x <-cols)
    {
      If(sourceDataFrame.count == sourceDataFrame.where(sourceDataFrame.col(x).isNull).count())
      {
        testState=true
      }else
      {
        return "Null Check Failed for: "+col
      }
    }
    return "No Null"
  }
  
  def duplicateCheck(sourceDataFrame: DataFrame,keys: String, path: String ): String{
    val cols = keys.split(",").map(_.trim)
    val resultDf = sourceDataFrame.groupBy(cols map col: _*).count().filter("count>1")
    if(resultDf.count()>0){
      writeToFile(resultDf,path,"csv")
      return "Tables has Duplicate records, Placed at: "+path
    }else{
      return "No Duplicates"
    }
  }
  
  def absoluteDuplicateCheck(sourceDataFrame: DataFrame,path: String ): String{
    val cols = sourceDataFrame.columns.toSeq
    val resultDf = sourceDataFrame.groupBy(cols map col: _*).count().filter("count>1")
    if(resultDf.count()>0){
      writeToFile(resultDf,path,"csv")
      return "Tables has Absolute Duplicate records, Placed at: "+path
    }else{
      return "No Absolute Duplicates"
    }
  }
   
  
   /**
    * Function to write a dataframe content into file.
    * @param dataFrame input dataframe
    * @param path output directory to write the file
    * @param format format of output file
    */
  def writeToFile(dataFrame: DataFrame,path: String,format: String): Unit = {
    dataFrame.write.mode(SaveMode.Append).format(format).save(path)
  }
  
  
  
}