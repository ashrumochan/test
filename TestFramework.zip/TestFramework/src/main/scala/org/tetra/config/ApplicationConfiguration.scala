package org.tetra.config

import com.typesafe.config.ConfigFactory
import scala.util.Properties

import scala.io;
import java.nio.file.{ Paths, Files }
import java.io.File

import scala.beans.{ BeanProperty, BooleanBeanProperty }

class ApplicationConfiguration {

  @BeanProperty
  var path: String = _

  @BeanProperty
  var numpartations: String = _

  @BeanProperty
  var insertmode: String = _

  @BeanProperty
  var hivedataformat: String = _

  @BeanProperty
  var tableName: String = _

  @BeanProperty
  var sqlFileName: String = _

  @BeanProperty
  var storeIntoAdl: Boolean = _

  @BeanProperty
  var storeIntoCSV: Boolean = _

  @BeanProperty
  var viewDatabase: String = _

  @BeanProperty
  var endDateStartDate: String = _
  @BeanProperty
  var pharmacyParquetPath: String = _
  def getConfigInfo(fileName: String): ConfigFactory = {

    val configFile = new File(fileName);

    val fileConfig = ConfigFactory.parseFile(configFile)
    val config = ConfigFactory.load(fileConfig)
    config
  }

}