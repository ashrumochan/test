package org.tetra.main

object MainApplication {
  
  def main(args: Array[String]): Unit = {
    print("Hello")
    
  }
  
}