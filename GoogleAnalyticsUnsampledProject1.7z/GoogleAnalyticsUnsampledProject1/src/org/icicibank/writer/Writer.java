package org.icicibank.writer;

import java.io.IOException;
import java.util.List;

public interface Writer {
	
	public long write(List<List<String>> dataObj,String fileName)throws IOException;

}
