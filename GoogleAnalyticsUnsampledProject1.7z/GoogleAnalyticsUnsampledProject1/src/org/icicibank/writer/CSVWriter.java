package org.icicibank.writer;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.log4j.Logger;
import org.icicibank.google.log.GaLogFactory;

public class CSVWriter implements Writer {
	public static Logger LOGGER = GaLogFactory.getGALogger();

	public long write(List<List<String>> rowDataList, String fileName)
			throws IOException {
		// TODO Auto-generated method stub
		// au.com.bytecode.opencsv.CSVWriter csvWriter = null;
		// additional header to be added
		
		LOGGER.debug("Received Data For Writing is:"+rowDataList.size());
		LOGGER.debug("FileName:- "+fileName);
		File file = new File(fileName /*+ ".csv"*/);
		if(!file.exists()){
			file.createNewFile();
		}
		List<String[]> csvData = Collections.emptyList();
		try (FileWriter writer = new FileWriter(file, true);
				au.com.bytecode.opencsv.CSVWriter csvWriter = new au.com.bytecode.opencsv.CSVWriter(
						writer)) {
			csvData = new ArrayList<String[]>();
			for (List<String> rowData : rowDataList) {
				csvData.add(rowData.toArray(new String[rowData.size()]));
			}
			
			csvWriter.writeAll(csvData);
			csvWriter.close();
		}
		LOGGER.debug("Number of rows written to file is:"+csvData.size());
       return Long.valueOf(""+csvData.size());
	}

}
