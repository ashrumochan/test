package org.icicibank.dao.data;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;
import org.icicibank.google.analytics.CustomProgressListener;
import org.icicibank.google.log.GaLogFactory;
import org.icicibank.writer.CSVWriter;

import com.google.api.services.analytics.model.GaData;
import com.google.api.services.drive.Drive;

public class DataPorter {
	public static Logger LOGGER = GaLogFactory.getGALogger();
	private String fromDate;
	private PropertiesConfiguration properties;
	private String bannerPosition;

	public String getFromDate() {
		return fromDate;
	}


	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}


	public PropertiesConfiguration getProperties() {
		return properties;
	}


	public void setProperties(PropertiesConfiguration properties) {
		this.properties = properties;
	}


	public String getBannerPosition() {
		return bannerPosition;
	}


	public void setBannerPosition(String bannerPosition) {
		this.bannerPosition = bannerPosition;
	}


	private void exportResultsToConsole(GaData results) {
		// Parse the response from the Core Reporting API for
		// the profile name and number of sessions.
		if (results != null && !results.getRows().isEmpty()) {
			System.out.println("View (Profile) Name: "
					+ results.getProfileInfo().getProfileName());
			System.out.println("Total Sessions: "
					+ results.getRows().get(0).get(0));

		} else {
			System.out.println("No results found");
		}
	}
	
	public void exportSampledDataToFile(GaData gaData,String filePath) throws IOException, ClassNotFoundException, SQLException {
		System.out.println("Priniting File initiated......");
		//BufferedWriter writer = null;
		LOGGER.debug("getDataFromGA initiated......");
		FileOutputStream fos = null;
		List<List<String>> dataResult = new ArrayList<List<String>>();
		PropertyFileReader propertyReader = null;
		if (gaData.getTotalResults() > 0) {
			try {
				
				System.out.println("Data Table:");
				for (List<String> rowValues : gaData.getRows()) {
					if (dataResult.size() <= 500) {
						dataResult.add(rowValues);
					} else {
						//dataLoad.gaClickViewTMPLoad(con, dataResult);
						CSVWriter csvWriter = new CSVWriter();
						try {
							LOGGER.debug("csvWriter is excelToCSV:");
							csvWriter.write(dataResult, filePath);
						} catch (Exception e) {
							e.printStackTrace();
						}
						dataResult.clear();
					}
					
				}

			} finally {

			}

		} else {
			System.out.println("No Results Found");
		}

			
	}
	
	public void exportDataFromGDriveToFile(Drive service, String fileId,String filePath) throws IOException, ClassNotFoundException, SQLException {
		System.out.println("Priniting File initiated......");
		//BufferedWriter writer = null;
		LOGGER.debug("getDataFromGA initiated......");
		FileOutputStream fos = null;
		try {
			
			com.google.api.services.drive.Drive.Files.Get request = service
					.files().get(fileId);
			
			//writer = new BufferedWriter(new FileWriter(new File(properties.getString("GA_DOWNLOAD_PATH")+ gFile.getTitle())));
			File file = new File(filePath);
			if(file.exists()){
				file.delete();
			}
			fos = new FileOutputStream(new File(filePath),true);
			request.getMediaHttpDownloader().setProgressListener(new CustomProgressListener());
			
				request.executeMediaAndDownloadTo(fos);
		}
		finally {
			if (null != fos) {
				fos.close();
			}
			service.files().delete(fileId).execute();
		}
			
	}
	
	public void exportToCSV(Connection con, String fileName, String fromDate)
			throws SQLException, IOException, ClassNotFoundException {
		List<List<String>> finalDataList = new ArrayList<List<String>>();
		Statement statement = null;
		// try (Connection con = ConnectionUtility.getConnection(properties)) {
		try {
			String exportQuery = properties.getString("export_query");
			exportQuery = MessageFormat.format(exportQuery, fromDate);
			LOGGER.debug("exportQuery is:" + exportQuery);
			statement = con.createStatement();
			// statement.setString(1,fromDate);
			ResultSet rs = statement.executeQuery(exportQuery);
			int columnCount = rs.getMetaData().getColumnCount();
			//System.out.println("columnCount+++" + columnCount);
			List<String> listData = null;
			fileName = "GAData_" + fromDate;
			LOGGER.debug("MetaData Max Columns Count is:" + columnCount);
			while (rs.next()) {
				int count = 0;
				//System.out.println("initial count:" + count);
				listData = new ArrayList<String>(columnCount);
				for (int i = 1; i <= columnCount; i++) {
					
					listData.add(String.valueOf(rs.getObject(i)));
				}
				finalDataList.add(listData);
				count++;
				//System.out.println("initial count:" + count);
			}
			// LOGGER.debug("finalDataList is:" +finalDataList);

			CSVWriter csvWriter = new CSVWriter();
			try {
				LOGGER.debug("csvWriter is excelToCSV:");
				csvWriter.write(finalDataList, fileName);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (statement != null)
				statement.close();
		}

		/*
		 * } catch (ClassNotFoundException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); } catch (SQLException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); }
		 */
	}

}
