package org.icicibank.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertyFileReader {
	private String configFilePath;
	private Properties property;
	private InputStream inputStream;
	
	public PropertyFileReader(){
		property = new Properties();
	}
	
	public PropertyFileReader(String configFilePath) throws IOException{
		property = new Properties();
		inputStream = new FileInputStream(new File(configFilePath));
		property.load(inputStream);
	}
	public String getConfigFilePath() {
		return configFilePath;
	}

	public void setConfigFilePath(String configFilePath) throws IOException {
		this.configFilePath = configFilePath;
		inputStream = new FileInputStream(new File(configFilePath));
		property.load(inputStream);
	}

	public Properties getProperty() {
		return property;
	}

	public void setProperty(Properties property) {
		this.property = property;
	}
	

}
