package org.icicibank.google.calander;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.apache.log4j.Logger;
import org.icicibank.google.analytics.GAInitializer;
import org.icicibank.google.log.GaLogFactory;

public class DateUtil {
	
	/*static public String getNextDateString(String Date){
		
	}*/
public static Logger LOGGER = GaLogFactory.getGALogger();	
static public String getFormattedDate(String dateStr,String fromFormat,String toFormat) throws ParseException{
		LOGGER.debug("Received Date is:"+dateStr);
		SimpleDateFormat formatter = new SimpleDateFormat(fromFormat);//"yyyyMMdd"
        Date fromDateObj = formatter.parse(dateStr);
        SimpleDateFormat formatter2 = new SimpleDateFormat(toFormat);
		return formatter2.format(fromDateObj);
		
	}
	
	static public String getNextDateString(String dateStr,String format) throws ParseException{
		
		GregorianCalendar calendar = new GregorianCalendar();
		SimpleDateFormat formatter = new SimpleDateFormat(format);//"yyyyMMdd"
        Date fromDateObj = formatter.parse(dateStr);
		calendar.setTime(fromDateObj);
		calendar.add(Calendar.DATE, 1);
		return formatter.format(calendar.getTime());
		
	}
	
	static public List<Date> getDates(String fromDateStr,String toDateStr,String format) throws ParseException{
		//Calendar calendar = Calendar.getInstance();
		List<Date> result = new ArrayList<Date>();
		GregorianCalendar fromCalendar = new GregorianCalendar();
		SimpleDateFormat formatter = new SimpleDateFormat(format);//"yyyyMMdd"
        Date fromDateObj = formatter.parse(fromDateStr);
		fromCalendar.setTime(fromDateObj);
        
        GregorianCalendar toCalendar = new GregorianCalendar();
		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date toDateObj = formatter.parse(toDateStr);
        toCalendar.setTime(toDateObj);
        
        while(fromCalendar.compareTo(toCalendar)<0){
        	result.add(fromCalendar.getTime());
        	fromCalendar.add(Calendar.DATE, 1);
        }
        LOGGER.debug("getDates:"+result);
		return result;
		
	}
	
	static public int compareDates(String fromDateStr,String toDateStr,String format) throws ParseException{
		int result=0;
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		 Date fromDateObj = formatter.parse(fromDateStr);
		 Date toDateObj = formatter.parse(toDateStr);
		 LOGGER.debug("compareDates return:"+toDateObj.compareTo(fromDateObj));
		return toDateObj.compareTo(fromDateObj);
	}
	
	static public String getCurrentDate(String format){
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		LOGGER.debug("compareDates return:"+formatter.format(calendar.getTime()));
		return formatter.format(calendar.getTime());
	}

	/*public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		
		System.out.println(DateUtil.getDates("2015-12-01", "2016-02-01"));

	}*/

}
