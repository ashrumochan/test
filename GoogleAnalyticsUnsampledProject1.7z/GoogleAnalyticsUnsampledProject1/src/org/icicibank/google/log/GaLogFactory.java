package org.icicibank.google.log;

import java.io.IOException;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;


public class GaLogFactory  {

	public static  Logger gaLogger=Logger.getLogger("org.icicibank.google.analytics");


	public static Logger getGALogger() {

		//gaLogger.setLevel(Level.INFO.DEBUG.ERROR.WARN);

		PatternLayout layout = new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n");
		gaLogger.addAppender(new ConsoleAppender(layout));
		try {
			RollingFileAppender fileAppender = new RollingFileAppender(layout, "/etlcache1/GA_UNSAMPLED/application.log");
			//RollingFileAppender fileAppender = new RollingFileAppender(layout, "D:/Work/GoogleAnalytics/application.log");
			fileAppender.setMaxBackupIndex(500);
			fileAppender.setMaxFileSize("50MB");
			fileAppender.setImmediateFlush(true);
			fileAppender.setAppend(true);
			gaLogger.addAppender(fileAppender);
		} catch (IOException e) {

			e.printStackTrace();
		}
		//System.out.println("PROCEDURELogger : "+staticProcedureLogger.getName());
		return gaLogger;

	}
	
}
