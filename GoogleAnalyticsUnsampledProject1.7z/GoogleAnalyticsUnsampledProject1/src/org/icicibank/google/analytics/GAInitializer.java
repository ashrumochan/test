package org.icicibank.google.analytics;

import java.io.File;
import java.sql.SQLException;
import java.text.ParseException;

import javax.net.ssl.SSLHandshakeException;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.icicibank.dao.data.DataPorter;
import org.icicibank.google.calander.DateUtil;
import org.icicibank.google.log.GaLogFactory;

//import sun.org.mozilla.javascript.internal.ast.ThrowStatement;

/**

 * This program does the following tasks:
 * - the application has to check "date_range" property and check if it has completed, 
 *     once the lag dates are completed it has to remove it.
 * - The application has to check if the program has completed for the received date from scheuler.
 * - create a checkpoint file for the data when the applicaton has completed its task of execution
 *  
 * @author BAN97267
 *
 */
public class GAInitializer {
	
	public static Logger LOGGER = GaLogFactory.getGALogger();
	private PropertiesConfiguration  properties;
	
	public PropertiesConfiguration  getProperties() {
		return properties ;
	}

	public void setProperties(PropertiesConfiguration  properties) {
		this.properties = properties;
	}

	public PropertiesConfiguration loadProperyFile(String[] args ) throws ConfigurationException{
		File configFile = null;
		PropertiesConfiguration config = new PropertiesConfiguration();
		if(args.length>0 && !StringUtils.isEmpty(args[0])){
			configFile = new File(args[0]);
			System.out.println(configFile);
			//To-Do currently handling only for a file
			if(configFile.exists()&&configFile.isFile()){
				LOGGER.warn("Loading given configuration Properties");
				config.load(configFile);
			}
			else{
				LOGGER.warn("Unable to load the given property file!,Fetching properties from Default properties");
				configFile = new File("config.properties");
				config.load(configFile);
			}
		}
		else{
			LOGGER.warn("No property files are specified");
			configFile = new File("resources/config.properties");	
			config.load(configFile);
		}
		return config;
	}
	
	
	
	
	public String getToDate(){
		String lagDate = properties.getString("lag_date");
		String toDateStr = null;
		if (!StringUtils.isEmpty(lagDate)){
			String datesArr[] = lagDate.split("-");
			if(datesArr.length>2&&!StringUtils.isEmpty(datesArr[1]))
				toDateStr = datesArr[1];
		}
		else{
			toDateStr = DateUtil.getCurrentDate("yyyyMMdd");
		}
		
		return toDateStr;
	}
	
	/*
	 * here there are two cases
	 * 3. When execution date is received from property file this can happen in case of failure
	 * 2. When date input is received as an argument
	 * 1. when it is first time and lagDate argument is provided
	 */
	public String getExecutionInitDateStr(String[] args) throws IllegalArgumentException, ParseException {
		String lagDate = properties.getString("lag_date");//Previous date conditions
		String executionDate = properties.getString("executed_date");//LAst Executed Date
		LOGGER.debug("Received lag Date is:"+lagDate);
		LOGGER.debug("Received executedDate is:"+executionDate);
		if(StringUtils.isEmpty(lagDate)){
			String argsDate = args[1];
			
			
			if(args.length>1&&!StringUtils.isEmpty(args[0])){
				executionDate =args[0];
			}
			else if(StringUtils.isEmpty(executionDate)){
				executionDate = DateUtil.getCurrentDate("yyyymmdd");
			}
			else{
				executionDate = DateUtil.getNextDateString(executionDate, "yyyymmdd");
			}
			
			
		}
		else{
			String dates[] = lagDate.split("-");
			executionDate = (!StringUtils.isEmpty(dates[0]))?dates[0]:(StringUtils.isEmpty(executionDate)?DateUtil.getCurrentDate("yyyymmdd"):DateUtil.getNextDateString(executionDate, "yyyymmdd"));
			
		}
		
		return executionDate;
	}
	

	/**
	 * @author BAN97267
	 * @param dimensions -- Dimensions that need to get from Google Analytics
	 * @param metrics -- Metrics that need to get from Google Analytics
	 * @param filters -- Filters that need applied on Google Analytics data
	 * @param sortKey -- Sorting key
	 * @param startDate -- From date 
	 * @param endDate -- To date
	 * @param filename -- File name(with path) to store the extracred GA data
	 */
	public void executeGa(String dimensions,String metrics,String filters, String sortKey, String startDate, String endDate,String filename){
		
		try{
			if(startDate.isEmpty() || endDate.isEmpty() || startDate==null || endDate==null){
				LOGGER.error("Invalid StartDate and Enddate");
				System.exit(0);
			}
		}catch(NullPointerException e){
			LOGGER.error("Check Start and End Date");
			System.exit(0);
		}
		
		
		LOGGER.error("Received Dates, Start Date:- "+startDate+" End Date:- "+endDate);
		
		int res = 0;
		String format = "yyyy-MM-dd";
		GADataPorter googleAnalytics = new GADataPorter();
		DataPorter dataPersister = new DataPorter();
		dataPersister.setProperties(properties);
		
		
		try{
			res = DateUtil.compareDates(startDate, endDate, format);
			while(res>=0){
				googleAnalytics.setFromDate(startDate);
				googleAnalytics.setToDate(endDate);
				googleAnalytics.setProperties(properties);
				googleAnalytics.setDimesions(dimensions);
				googleAnalytics.setMetrics(metrics);
				googleAnalytics.setFilters(filters);				
				googleAnalytics.setSortKey(sortKey);
				googleAnalytics.setFileName(filename);
				System.out.println("====Executing for====="+startDate);
				
				dataPersister.setBannerPosition(filename);
				dataPersister.setFromDate(startDate);
				googleAnalytics.setDataPersister(dataPersister);
				
				//googleAnalytics.init(connection,1);
				try{
					LOGGER.info("====Executing for===Date:=="+startDate+"  Report ID:"+filename);
					
					//googleAnalytics.init(connection,1);
					googleAnalytics.init(1);
				}
				catch(SSLHandshakeException ssle){
					ssle.printStackTrace();
					LOGGER.error(ssle.getMessage());
				}
									
				//String fileName = "GAData_"+ fromDateStr + "_" + command + ".csv";
				//dataPersister.exportToCSV(connection,fileName,fromDateStr);
				startDate = DateUtil.getNextDateString(startDate, format);
				LOGGER.debug("Date Comparision result is:"+res);
				LOGGER.debug("Prepared Dates ARe:"+startDate+"-"+endDate);
				res = DateUtil.compareDates(startDate, endDate, format);
			}
		}
		catch(NullPointerException e){
			LOGGER.info("Check Start date and End Date");
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		} catch (ParseException e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		}
		
	}
	// arg0 for property file path
	//arg1 for date The date has to in YYYYMMDD
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
			GAInitializer sets = new GAInitializer();
			PropertiesConfiguration properties = null;
			//if(null==sets.getProperties()){
				properties = sets.loadProperyFile(args);
			//}

			sets.setProperties(properties);
			
			//String dimensions ="ga:dimension1,ga:dimension12,ga:dimension14,ga:eventCategory";
			String dimensions ="ga:dimension1,ga:city,ga:mobileDeviceModel,ga:screenName";
			String metrics ="ga:timeOnScreen";
			String filters ="ga:date==20180725;ga:hour==00;ga:dimension1=~[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]";
			String sortKey ="ga:dimension1";
			String startDate ="2018-10-20";
			String endDate ="2018-10-21";
			String filename ="D:/data_GD/drive-java-quickstart/GA_2018-08-01.csv";
			
			String fromDateStr = startDate;//sets.getExecutionInitDateStr(args);
			properties.setProperty("executed_date", fromDateStr);		
					
			String toDateStr =endDate;//DateUtil.getCurrentDate("yyyyMMdd");//sets.getToDate();
			String command = null;
			command = (args.length>2)?command=args[2]:properties.getString("command");
			System.out.println(fromDateStr+" "+toDateStr+" "+command);
			
					
		     /*sets.executeGA(fromDateStr, toDateStr,command, "yyyyMMdd");*/
			
			sets.executeGa(dimensions, metrics, filters, sortKey, startDate, endDate, filename);
		     properties.save();
			
		} catch ( ConfigurationException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			throw new Exception(e.getMessage());
			
		}
		catch(Exception e){
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

}
